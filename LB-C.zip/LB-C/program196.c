#include<stdio.h>

void DisplayI()
{
    int iCnt=1;  //auto variable

    while(iCnt<=4)
    {
        printf("Jay Ganesh...\n");
        iCnt++;
    }

}

void DisplayR()
{
   static int iCnt=1;   //static variable

    if(iCnt<=4)
    {
        printf("Jay Ganesh...\n");
        iCnt++;
        DisplayR();
    }

}
int main()
{
    DisplayR();

    return 0;
}