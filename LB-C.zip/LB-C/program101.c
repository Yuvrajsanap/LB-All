#include <stdio.h>
#include<stdbool.h>

bool ConvertCapital(char cValue){

   return cValue-32;
}

int main()
{
    char ch='\0';
    char cRet='\0';

    printf("ENter the character \n");
    scanf("%c",&ch);

    cRet=ConvertCapital(ch);

    printf("letter is %c\n",cRet);
    return 0;
}