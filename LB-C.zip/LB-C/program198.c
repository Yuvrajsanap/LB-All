#include<stdio.h>

void DisplayI()
{
    int iCnt=1;

    while(iCnt<=5)
    {
        printf("*\n");
        iCnt++;
    }

}
int main()
{
    DisplayI();

    return 0;
}