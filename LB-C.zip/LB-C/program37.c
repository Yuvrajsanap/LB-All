#include <stdio.h>
 #include<stdbool.h>

   
   void DisplayFactor(int iNo)
   {
    int iCnt=0;
    int iFact=1;
    printf("Factors of %d are \n",iNo);

    for(iCnt =1; iCnt<=iNo; iCnt++){
        iFact*=iCnt;
    }
    printf("%d",iFact);
   }
 

int main()
{
    int ivalue =1;

    printf("Enter the number \n");
    scanf("%d",&ivalue);
    DisplayFactor(ivalue);

    return 0;
}


//To calculate factorial 
// #include<stdio.h>

// int main()
// {
//     int n,i;
//     int factorial=1;

//     printf("Enter the number\n");
//     scanf("%d",&n);

//     if(n<0)
//     {
//         printf("factorial of negative number does not exist\n");
//     }
//     else{
//         for(i=1;i<=n;i++)
//         {
//             factorial*=i;
//         }
//         printf("factorial is %d\n",factorial);
//     }
//     return 0;
// }


