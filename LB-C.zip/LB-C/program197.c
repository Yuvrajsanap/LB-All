#include<stdio.h>

void DisplayR()
{
   static int iCnt=1;   //static variable

    if(iCnt<=4)
    {
        printf("Jay Ganesh...\n");
        iCnt++;
        DisplayR();

    }

}
int main()
{
    DisplayR();
    return 0;
}

//1: Memory for local variable
// 2 : Input parameter
//3 : Address of next Instruction
//4 : Value of old EBP