#include <stdio.h>
#include<stdbool.h>

bool Checkcapital(char cValue){

    if((cValue>='A') && (cValue<='Z')){
        return true;
    }
    else{
        return false;
    }
}

int main()
{
    char ch='\0';
    bool bRet=false;
    printf("ENter the character \n");
    scanf("%c",&ch);

    bRet=Checkcapital(ch);
    if(bRet==true){
        printf("It is a capital letter\n");
    }else{
        printf("It is not capital value\n");
    }
    return 0;
}