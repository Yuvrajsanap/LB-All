#include <stdio.h>
int main()
{
    char ch='\0';

    printf("Enter the character : \n");
    scanf("%c",&ch);

    printf("ASCII value is DECIMAl is %d\n",ch);
    printf("ASCII value is OCTAl is %o\n",ch);
    printf("ASCII value is HEXADECIMAL is %x\n",ch);
    return 0;
}