#include<stdio.h>

int SumDisplayI(int Arr[],int isize)
{
    int iCnt=0;
    int iEven=0;


    while(iCnt<isize)
    {
        if(Arr[iCnt]%2==0)
        {
            iEven++;
        }
        iCnt++;
    }
    return iEven;
}
int main()
{
    int Arr[5]={10,20,30,40,50};
    int iRet=0;

    iRet=SumDisplayI(Arr,5);
    printf("Sum is:%d\n",iRet);

    return 0;
}