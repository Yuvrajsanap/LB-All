#include <stdio.h>

int Count(char str[],char ch){
    int iCnt=0;

    while(*str != '\0'){
        if(*str==ch){

            iCnt++;
        }
        str++;
    }
    return iCnt;
}

int main()
{
    char Arr[20];
    char iValue='\0';

    int iRet=0;

    printf("Enter the strind \n");
    scanf("%[^'\n']s",Arr);

    printf("Enter the character \n");
    scanf(" %c",&iValue);

    iRet=Count(Arr,iValue);

    printf("length of the string is %d\n",iRet);


    return 0;
        
}