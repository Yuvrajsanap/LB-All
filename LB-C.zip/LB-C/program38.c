// #include<stdio.h>
// #include<stdbool.h>
   
//  int  sumFactor(int iNo)
//    {
//     int iCnt=0;
//     int sum=0;
// //    1               2          3
//     for(iCnt =1; iCnt<=(iNo/2); iCnt++){
//         if((iNo % iCnt )==0){ //4
//     sum =sum+ iCnt;
//         }
//     }

//     return sum;
//    }
 
// int main()
// {
//     int ivalue =0;
//     int iRet=0;


//     printf("Enter the number \n");
//     scanf("%d",&ivalue);
    
//     iRet=sumFactor(ivalue);
//     printf("sum is %d\n",iRet);
//     sumFactor(ivalue);

//     return 0;
// }

// //Time comlexity 0(N/2)

#include<stdio.h>

int SumFact(int iNo)
{
    int i=0;
    int factorial=1;
    int sum=0;

    for(i=1;i<=iNo;i++)
    {
        factorial=factorial*i;
        sum+=factorial;
    }
    return sum;

}
int main()
{
    int iValue=0;
    printf("Enter the number\n");
    scanf("%d",&iValue);

    int iRet=0;

    iRet=SumFact(iValue);
    printf("Sum is %d\n",iRet);
    return 0;
}