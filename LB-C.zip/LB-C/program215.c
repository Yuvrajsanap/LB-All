#include<stdio.h>

int SumDisplayR(int Arr[],int isize)
{
   static int iCnt=0;
   static int iSum=0;


    if(iCnt<isize)
    {
        iSum=iSum+Arr[iCnt];
        iCnt++;
        SumDisplayR(Arr,isize);
    }
    return iSum;
}
int main()
{
    int Arr[5]={10,20,30,40,50};
    int iRet=0;

    iRet=SumDisplayR(Arr,5);
    printf("Sum is:%d\n",iRet);

    return 0;
}