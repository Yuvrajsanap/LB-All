printf("ENter star");
    // scanf("%d",&iValue);