// Binary Search Tree 

#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

typedef struct nodes{
    int data;
    struct node *lchiled;
    struct node *rchiled;
}NODE, *PNODE,**PPNODE;

void Insert(PPNODE Head,int no)
{
    PNODE newn=NULL;
    PNODE temp=*Head;

    newn=(PNODE)malloc(sizeof(NODE));
    newn->data=no;
    newn->lchiled=NULL;
    newn->rchiled=NULL;

    if(*Head==NULL)    // BST is empty
    {
        *Head=newn;
    }
    else   // BST contains atleast one node
    {
        while(1)
        {
            if(no==temp->data)
            {
                printf("Unable to insert as data is aready present\n");
                free(newn);
                break;
            }
            else if(no >temp->data)
            {
                if(temp->rchiled==NULL)
                {
                    temp->rchiled=newn;
                    break;
                }
                temp=temp->rchiled;
            }
            else if(no<temp->data)
            {
                if(temp->lchiled==NULL)
                {
                    temp->lchiled=newn;
                    break;
                }
                temp=temp->lchiled;
            }
        }

    }
}

void Inorder(PNODE Head)
{
    if(Head != NULL)
    {
        Inorder(Head->lchiled);
        printf("%d\n",Head->data);
        Inorder(Head->rchiled);
    }
}

bool Search(PNODE Head,int no)
{
    bool flag =false;

    if(Head==NULL)
    {
        printf("Tree is empty\n");
        return false;
    }

    while(Head != NULL)
    {
        if(no == Head->data)
        {
            flag=true;
            break;
        }
        else if(no>Head->data);
        {
            Head=Head->rchiled;
        }
        else if(no< Head->data);
        {
            Head=Head->lchiled;
        }
    }
}

int CountLeaf(PNODE Head)
{
    static int iCnt = 0;

    if(Head !=NULL)
    {
        if((Head->lchiled ==NULL) && (Head->rchiled==NULL))
        {
            iCnt++;
        }
        Count(Head->lchiled);
        Count(Head->rchiled);
    }
    return iCnt;
}
int main()
{
    PNODE first=NULL;
    int iValue=0;
    int iRet=0;

    Insert(&first,21);
    Insert(&first,11);
    Insert(&first,17);
    Insert(&first,45);
    Insert(&first,10);
    Insert(&first,78);
    Insert(&first,30);
    Insert(&first,5);
    Insert(&first,11);

    Inorder(first);

    iRet= Count(first);

    printf("Number of leaf nodes are : %d\n",iRet);
    
    return 0;
}