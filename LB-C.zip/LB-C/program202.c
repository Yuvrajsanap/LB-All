#include<stdio.h>

void Factors(int iNo)
{
    int iCnt=1;

   for(iCnt=1;iCnt<=(iNo/2);iCnt++){
    if((iNo%iCnt)==0)
    {
        printf("%d\n",iCnt);
    }
   }

}

void FactorsI(int iNo)
{
    int iCnt=1;

  while(iCnt<=(iNo/2))
  {
    if((iNo%iCnt)==0)
    {
        printf("%d\n",iCnt);
    }
        iCnt++;
  }
}
void FactorsR(int iNo)
{
    int static iCnt=1;

    while(iCnt)
    if(iCnt<=iNo)
    {
        printf("%d\n",iCnt);
        iCnt++;
        DisplayR(iNo);
    }
}
int main()
{
    int iValue=0;

    printf("Enter the number :\n");
    scanf("%d",&iValue);

    FactorsI(iValue);

    return 0;
}