#include<stdio.h>

void DisplayI(int iNo)
{
    int iCnt=1;

    while(iCnt<=iNo)
    {
        printf("%d\n",iCnt);
        iCnt++;
    }

}

void DisplayR(int iNo)
{
    int static iCnt=1;

    if(iCnt<=iNo)
    {
        printf("%d\n",iCnt);
        iCnt++;
        DisplayR(iNo);
    }
}
int main()
{
    DisplayR(4);

    return 0;
}