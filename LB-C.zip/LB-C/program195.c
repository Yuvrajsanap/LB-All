#include<stdio.h>

void Display()
{
    int iCnt=0;

    // for(iCnt=1;iCnt<=4;iCnt++){
    //     printf("Jay Ganesh...\n");
    // }

    iCnt=1;
    while(iCnt<=4)
    {
        printf("Jay Ganesh...\n");
        iCnt++;
    }

}
int main()
{
    Display();
    return 0;
}