#include<stdio.h>

int Factorial(int iNo)
{
      int iCnt=0;
      int iFact=0;

  while(iCnt<=iNo)
  {
    iFact=iFact * iCnt;
    iCnt++;
  }
  return iFact;
}
int main()
{
    int iValue=0, iRet=0;

    printf("Enter the number :\n");
    scanf("%d",&iValue);

  iRet= Factorial(iValue);
    printf(iRet);

    return 0;
}