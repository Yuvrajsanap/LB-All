#include<stdio.h>

void Display(int iNo)
{
    if(iNo>=1)
    {
        iNo--;
        Display(iNo);
        printf("%d\n",iNo);
    }
}
int main()
{
    Display(5);
    return 0;
}