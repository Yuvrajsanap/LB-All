    //DSA will be start.^
#include <stdio.h>
#include<stdlib.h>

//Structrure Declaration
struct node{
    int data;
    struct node *next;//self refrantial structrure.
};


int main()
{
    struct node *First=NULL;
    
    return 0;
}