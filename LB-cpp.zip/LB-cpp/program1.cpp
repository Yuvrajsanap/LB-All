#include<iostream>
using namespace std;

int main(){

    cout<<"gay ganesh"<<endl;
    return 0;
}