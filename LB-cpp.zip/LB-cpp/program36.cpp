#include<iostream>
using namespace std;

typedef struct node{  //Doubly Circular Linked List
    int data;
    struct node *next;
    struct node *prev;
}NODE,*PNODE,**PPNODE;

class DoublyCL
{
    private:
    PNODE first;
    PNODE last;
    int Count;

    public:
    DoublyCL();
    void InsertFirst(int no);
    void InsertLast(int no);
    void Display();
    int CountNode();
    void DeleteFirst();
    void DeleteLast();
    void InsertAtPos(int iPos,int no);
    void DeleteAtPos(int iPos);
};

DoublyCL::DoublyCL()
{
    cout<<"Inside Constructer\n";
    first=NULL;
    last=NULL;
    Count=0;
}
void DoublyCL::InsertFirst(int no)
{
    PNODE newn=new NODE;

    newn->data=no;
    newn->next=NULL;
    newn->prev=NULL;

    if((first==NULL) && (last==NULL)){
        first=newn;
        last=newn;
    }
    else
    {
        newn->next=first;
        first->prev=newn;
        first=newn;
    }
    last->next=first;
    first->prev=last;

    Count++;
}

void DoublyCL::InsertLast(int no)
{
    PNODE newn=new NODE;

    newn->data=no;
    newn->next=NULL;
    newn->prev=NULL;

    if((first==NULL) && (last==NULL))
    {
        first=newn;
        last=newn;
    }
    else
    {
        newn->prev=last;
        last->next=newn;
        last=newn;
    }
    last->next=first;
    first->prev=last;

    Count++;
}
void DoublyCL::Display()
{

    cout<<"Element of the linked list are:\n";
    if((first!=NULL) && (last!=NULL)){
   do
   {
        cout<<"|"<<first->data<<"|<=>";
        first=first->next;
    }while(first!=last->next);
   }
   cout<<"Address of first node\n";
}
int DoublyCL::CountNode()
{
    return Count;
}
void DoublyCL::DeleteFirst()
{
    if((first==NULL) && (last==NULL)){
        return;
    }
    else if((first==last)){
        delete first;
        first=NULL;
        last=NULL;
    }
    else
    {
        first=first->next;
        delete last->next;
        first->prev=last;
        last->next=first;
    }
    Count--;
}
void DoublyCL::DeleteLast()
{
    if((first==NULL) && (last==NULL)){
        return;
    }
    else if(first==last){
        delete last;
        first=NULL;
        last=NULL;
    }
    else
    {
        last=last->prev;
        delete first->prev;
        first->prev=last;
        last->next=first;
    }
    Count--;
}

void DoublyCL::InsertAtPos(int iPos,int no)
{
    if((iPos<1) || (iPos>(Count+1))){
        cout<<"Invalid position\n";
        return;
    }

    if(iPos==1){
        InsertFirst(no);
    }
    else if(iPos==(Count+1)){
        InsertLast(no);
    }
    else
    {
        int i=0;
        PNODE temp=first;

        PNODE newn=new NODE;
        newn->data=no;
        newn->next=NULL;
        newn->prev=NULL;

        for(i=1;i<iPos-1;i++){
            temp=temp->next;
        }
        newn->next=temp->next;
        temp->next->prev=newn;
        temp->next=newn;
        newn->prev=temp;
    }
    Count++;
}
void DoublyCL::DeleteAtPos(int iPos){
    if((iPos<1) || (iPos>(Count))){
        cout<<"Invalid position\n";
        return;
    }

    if(iPos==1){
        DeleteFirst();
    }
    else if(iPos==(Count)){
        DeleteLast();
    }
    else
    {
        int i=0;
        PNODE temp=first;

        for(i=1;i<iPos-1;i++){
            temp=temp->next;
        }

    temp->next=temp->next->next;
    delete temp->next->prev;
    temp->next->prev=NULL;
    }
    Count--;
}
int main()
{
     DoublyCL obj;
    int iRet=0;

    obj.InsertFirst(111);
    obj.InsertFirst(101);
    obj.InsertFirst(51);
    obj.InsertFirst(21);
    obj.InsertFirst(11);
    obj.Display();
    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";

    obj.InsertLast(121);
    obj.InsertLast(151);
     obj.Display();
    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";

    obj.DeleteFirst();
     obj.Display();

    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";

    obj.DeleteLast();
     obj.Display();

    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";

    obj.InsertAtPos(3,105);
    obj.Display();

    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";

    obj.DeleteAtPos(5);
    obj.Display();

    iRet=obj.CountNode();
    cout<<"Number of element in the linked list are:"<<iRet<<"\n";
    
    return 0;
}