#include<iostream>
using namespace std;

class Array{

    private:
    int *Arr;   
    int iSize;

    public:
    Array(int X){             //paramitrise constructer
        iSize=X;
        Arr=new int[iSize];
    }
    ~Array(){                  //Destructer
        delete []Arr;
    }
    void Accept(){                       //Member function
        int iCnt=0;
        cout<<"pleace enter the number"<<endl;
        for(iCnt=0;iCnt<iSize;iCnt++){
            cin>>Arr[iCnt];
        }
    }
    void Display(){                       ////Member function
        cout<<"Element of the array"<<endl;
        int iCnt=0;
        for(iCnt=0;iCnt<iSize;iCnt++){
            cout<<Arr[iCnt]<<"\t";

        }
        cout<<endl;
    }

    int AdditionEven(){
        int iSum=0,iCnt=0;

        for(iCnt=0;iCnt<iSize;iCnt++){
            if((Arr[iCnt]%2)==0){
            iSum=iSum+Arr[iCnt];
        }
    }
        return iSum;
    }
};
int main()
{

    int iLength=0;
    int iRet=0;

    cout<<"Enter the element that you want"<<endl;
    cin>>iLength;

    Array *aobj=new Array(iLength);

    aobj->Accept();
    aobj->Display();
    
    iRet=aobj->AdditionEven();

    cout<<"Additon of even number :"<<iRet<<endl;
    delete aobj;

    return 0;
}