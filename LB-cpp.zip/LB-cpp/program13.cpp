#include<iostream>
using namespace std;

class Digit{

    private :
    int iNo;

    public:
    Digit(int x){
        iNo=x;
    }

    int Factorial(){
        int iFact=1;
        int iCnt=0;

        for(iCnt=1;iCnt<=iNo;iCnt++){
            iFact=iFact*iCnt;
        }
    return iFact;
    }
};
int main(){

    int iValue=0;
    int iRet=0;

    cout<<"Enter the number "<<endl;
    cin>>iValue;

    Digit *nobj =new Digit(iValue);
    
    iRet=nobj->Factorial();

    cout<<"Factorial is :"<<iRet<<endl;

    return 0;
}