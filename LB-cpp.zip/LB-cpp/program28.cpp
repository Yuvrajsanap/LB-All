#include<iostream>
using namespace std;

int Addition(int Arr[],int Length)
{
    int Sum=0,iCnt=0;

    for(iCnt=0;iCnt<Length;iCnt++){
        Sum=Sum+Arr[iCnt];
    }
    return Sum;
}
int main()
{
    int Size=0;
    int *ptr=NULL;
    int iCnt=0,Ret=0;

    //step 1;
    cout<<"Enter number of elements :"<<"\n";
    cin>>Size;

    //strp 2
    ptr=new int[Size];

    //step 3
    cout<<"Enter the elements:"<<"\n";
    for(iCnt=0;iCnt<Size;iCnt++){
        cin>>ptr[iCnt];
    }

    // strp 4
    //function call

    Ret=Addition(ptr,Size);
    cout<<"Adition of all elements is :"<<Ret<<"\n";


    cout<<"\n";

    // step 5
    delete[]ptr;

    return 0;
}