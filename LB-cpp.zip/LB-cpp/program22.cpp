#include<iostream>
using namespace std;

template <class T>
void Swap(T &No1,T &No2){//call by refrance function.
   
    T Temp;
    Temp=No1;
    No1=No2;
    No2=Temp;
}
int main()
{
    double fValue1=20.3;
    double fValue2=10.5;

    cout<<"Value of iVAle1:  "<<fValue1<<"\n";
    cout<<"Value of iVAle2 : "<<fValue2<<"\n";

    Swap(fValue1,fValue2);

    cout<<"Value of iVAle1:  "<<fValue1<<"\n";
    cout<<"Value of iVAle2 : "<<fValue2<<"\n";

    return 0;
}