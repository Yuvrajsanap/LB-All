#include<iostream>
using namespace std;

typedef struct node{
    int data;
    struct node *next;
}NODE,*PNODE,**PPNODE;

class SinglyCL
{
    private:
    PNODE first;
    PNODE last;
    int Count;

    public:
    SinglyCL();
    void InsertFirst(int no);
    void InsertLast(int no);
    void Display();
    int CountNode();
    void DeleteFirst();
    void DeleteLast();
    void InsertAtPos(int iPos,int no);
    void DeleteAtPos(int iPos);
};

SinglyCL::SinglyCL()
{
    first=NULL;
    last=NULL;
    Count=0;
}

void SinglyCL::InsertFirst(int no)
{   
    PNODE newn=NULL;
    newn=new NODE;

    newn->data=no;
    newn->next=NULL;

    if(first==NULL && last==NULL){
        first=newn;
        last=newn;
    }
    else
    {
        newn->next=first;
        first=newn;
    }
    last->next=first;
    Count++;
}
void SinglyCL::InsertLast(int no)
{
    PNODE newn=new NODE;

    newn->data=no;
    newn->next=NULL;

    if(first==NULL && last==NULL){
        first=NULL;
        last=NULL;
    }
    else
    {
        last->next=newn;
        last=newn;
    }
    last->next=first;
    Count++;
}
void SinglyCL::Display()
{
    cout<<"\nElement of the linked list are:\n";

    if(first!=NULL && last!=NULL){
        do{
            cout<<"|"<<first->data<<"|->";
            first=first->next;
        }while(first!=last->next);
        cout<<"Addres of first node:\n";
    }
}
int SinglyCL::CountNode()
{
    return Count;
}
void SinglyCL::DeleteFirst()
{
    if(first==NULL && last==NULL){
        return;
    }
    else if(first==last){
        delete first;
        first=NULL;
        last=NULL;
    }
    else
    {
        first=first->next;
        delete last->next;
        last->next=first;
    }
    Count--;
}
void SinglyCL::DeleteLast()
{
    PNODE temp=first;
     if(first==NULL && last==NULL){
        return;
    }
    else if(first==last){
        delete last;
        first=NULL;
        last=NULL;
    }
    else
    {
       while(temp->next!=last){
        temp=temp->next;
       }
       delete last;
       last=NULL;
       last->next=first;
    }
    Count--;
}
void SinglyCL::InsertAtPos(int iPos,int no)
{
    if((iPos<1) || (iPos>(Count+1))){
        return;
    }

    if(iPos==1){
        InsertFirst(no);
    }
    else if(iPos==(Count+1)){
        InsertLast(no);
    }
    else
    {
        PNODE temp=first;
        int i=0;
        PNODE newn=new NODE;

        newn->data=no;
        newn->next=NULL;

        for(i=1;i<iPos-1;i++){
            temp=temp->next;
        }
        newn->next=temp->next;
        temp->next=newn;
    }
}
void SinglyCL::DeleteAtPos(int iPos){
    if(iPos<1 || iPos>(Count)){
        return;
    }

    if(iPos==1){
        DeleteFirst();
    }
    else if(iPos==Count+1){
        DeleteLast();
    }
    else
    {   PNODE temp=first;
        int i=0;
        for(i=1;i<iPos-1;i++){
            temp=temp->next;
        }
        PNODE targatednode=temp->next;
        temp->next=temp->next->next;
        delete targatednode;
    }
}
int main()
{
    SinglyCL obj;
    int iRet=0;
    obj.InsertFirst(51);
    obj.InsertFirst(21);
    obj.InsertFirst(11);
    obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;

   obj.InsertLast(101);
   obj.InsertLast(121);
   obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;

    obj.DeleteFirst();
    obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;

    obj.DeleteLast();
    obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;

    obj.InsertAtPos(3,105);
    obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;

    obj.DeleteAtPos(4);
    obj.Display();
   iRet=obj.CountNode();
   cout<<"Total count of the element are:\n"<<iRet;
    return 0;
}