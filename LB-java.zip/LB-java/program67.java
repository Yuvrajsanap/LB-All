class node
{
    public int data;
    public node next;
    public node prev;  //#

    public node(int no)
    {
        data=no;
        next=null;
        prev=null;    //#
    }
}

class DoublyLL
{
    private node first;
    private int Count;

    public DoublyLL()
    {
        first=null;
        Count=0;
    }

    public void InsertFirst(int no)
    {
        node newn=new node(no);//newn node create and initialize with constructer

        if(first==null){ // ll is empty
            first=newn;
        }
        else
        {
            newn.next=first;
            first.prev=newn;   //#
            first=newn;
        }
        Count++;
    }

    public void InsertLast(int no){

        node temp=first;
        node newn=new node(no);

        if(first==null)
        {
            first=newn;
        }
        else
        {
            while(temp.next!=null)
            temp=temp.next;
        }
        temp.next=newn;
        newn.prev=temp;   //#
        
        Count++;
    }

    public void DeleteFirst(){
        if(first==null){
            return;
        }
        else if(first.next==null){
            first=null;
        }
        else
        {
            first=first.next;
            first.prev=null;     //#
            }
        Count--;
    }
    public void DeleteLast()
    { 
        if(first==null){
            return;
        }
        else if(first.next==null){
            first=null;
        }
        else
        {
           node temp=first;

           while(temp.next.next!=null){
            temp=temp.next;
           }
           temp.next=null;
        }
        Count--;
    }

    public void Display()
    {
        node temp=first;
        System.out.println("Elements of the linked list are :");
        System.out.print("null <=>");

        while(temp != null)
        {
            System.out.print("|"+temp.data+"|<=>");
            temp=temp.next;
        }
        System.out.println("null");
    }
    
    public int Count()
    {
        return Count;
    }

    public void InsertAtPos(int no,int iPos)
    {
        
        if(iPos<1 || iPos>(Count+1)){
            System.out.println("Invalid position");
            return;
        }

        if(iPos==1){
            InsertFirst(no);
        }
        else if(iPos==(Count+1)){
            InsertLast(no);
        }
        else
        {
            node newn=new node(no);
            node temp=first;
            int i=0;

            for(i=1;i<iPos;i++){
                temp=temp.next;
            }
            newn.next=temp.next;
            temp.next.prev=newn;   //#

            temp.next=newn;
            newn.prev=temp;       //#

            Count++;
        }
    }

    public void DeleteAtPos(int iPos)
    {
         if(iPos<1 || iPos>(Count)){
            System.out.println("Invalid position");
            return;
        }

        if(iPos==1){
            DeleteFirst();
        }
        else if(iPos==(Count)){
            DeleteLast();
        }
        else
        {
         int i=0;
         node temp=first;
         
         for(i=1;i<iPos;i++){
            temp=temp.next;
         }
         temp.next=temp.next.next;
         temp.next.prev=temp;    //#
         
         Count--;
        }
    }
}
class program67
{
    public static void main(String arg[])
    {
        int iRet=0;

        DoublyLL obj=new DoublyLL();

        obj.InsertFirst(51);
        obj.InsertFirst(21);
        obj.InsertFirst(11);

        obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

        obj.InsertLast(101);
        obj.InsertLast(111);
        obj.InsertLast(121);
        obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

        obj.DeleteFirst();
        obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

        obj.DeleteLast();
        obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

        obj.InsertAtPos(105,3);
         obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

        obj.DeleteAtPos(5);
         obj.Display();

        iRet=obj.Count();
        System.out.println("Number of element are :"+iRet);

    }
}