import java.util.Scanner;

public class program11 {

     public static int OFFBit(int iNo){  //15 bit
        int iMask=0x00004000;
        int iResult=0;

        iResult= iNo & iMask;

        if(iResult==iMask){       

             return (iNo ^ iMask);
        }
        else{
           return iNo;
        }
    }
      public static void main(String arg[]){
        Scanner sobj=new Scanner(System.in);
        int iNo=0;
        int iRet=0;
    

        System.out.println("Enter number");;
        iNo=sobj.nextInt();

        iRet=OFFBit(iNo);
        System.out.println("Update number :"+iRet);

       
    }
}
