import java.util.*;
//acept a string from user and display count of that word.
public class program71
{
    public static void main(String args[])
    {
        Scanner sobj=new Scanner(System.in);

        System.out.println("Enter the string:");
        String str=sobj.nextLine();

        str=str.trim();
       
        str=str.replaceAll("\\s"," ");
        
        System.out.println("Update string is :"+str);
    }
}