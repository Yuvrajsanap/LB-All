import java.util.Scanner;

public class program8 {
     public static int OFFBit(int iNo){
        int iMask=0x0000400;
        int iResult=0;

        iResult= iNo & iMask;

        if(iResult==iMask){         //11 bit is on

             return (iNo ^ iMask);
        }
        else{                    // bit is off
           return iNo;
        }
    }
      public static void main(String arg[]){
        Scanner sobj=new Scanner(System.in);
        int iNo=0;
        int iRet=0;
    

        System.out.println("Enter number");;
        iNo=sobj.nextInt();

        iRet=OFFBit(iNo);
        System.out.println("Update number :"+iRet);

       
    }
}

