import java.util.*;
//acept a string from user and display count of that word .... frequency
public class program77
{
    public static void main(String args[])
    {
        Scanner sobj=new Scanner(System.in);

        System.out.println("Enter the string:");
        String str=sobj.nextLine();

        System.out.println("Enter the word that you want to serch :");
        String Word=sobj.nextLine();

        Word=Word.trim();
       str=str.trim();

       str=str.replaceAll("\\s+"," ");

       str=str.replaceAll(Word,"");

       str=str.replaceAll("\\s+"," ");
       str=str.trim();


       System.out.println(("Updated string is :"+str));
    
    }
}