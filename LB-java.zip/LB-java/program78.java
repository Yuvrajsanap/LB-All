import java.util.*;
//acept a string from user and display count of that word .... frequency
public class program78
{
    public static void main(String args[])
    {
        Scanner sobj=new Scanner(System.in);

        System.out.println("Enter the string:");
        String str=sobj.nextLine();

        StringBuffer sbobj=new StringBuffer(str);

       str=sbobj.reverse();

       System.out.println("Updated string is "+sbobj);
    
    }
}