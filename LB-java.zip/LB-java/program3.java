import java.util.*;

public class program3 {
     public static void main(String arg[]){
        Scanner sobj=new Scanner(System.in);
        int iNo=0;
        int iMask=4;
        int iResult=0;

        System.out.println("Enter number");;
        iNo=sobj.nextInt();

        iResult=iNo & iMask;

        if(iResult==iMask){
            System.out.println("3 bit is on");
        }
        else{
            System.out.println("3 bit is OFF");
        }
       
    }
}
