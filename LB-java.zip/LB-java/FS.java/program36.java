import java.util.*;
import java.io.*;

class program36  //problems on string .IMP
{
    public static void main(String args[]) throws Exception
    {
        Scanner sobj=new Scanner(System.in);
        
        String str="    Hello     World  Demo   ";

        str=str.replaceAll(" ","");//replace all
        System.out.println(str);
    }
}
