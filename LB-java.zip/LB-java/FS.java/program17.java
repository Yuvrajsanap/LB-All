import java.util.*;
import java.io.*;

class program17 {
    public static void main(String arg[])
    { 
        Scanner sobj = new Scanner(System.in);

        System.out.println("Enter the name of file : ");
        String FileName =sobj.nextLine();

        try
        {
        File fobj=new File(FileName);

        boolean bret = false;

        bret=fobj.exists();    //check file is exixt or not    
        if(bret)   //if(bret==true)
        {
            System.out.println("Name of file is "+fobj.getName());
            System.out.println("Name of file is "+fobj.getAbsolutePath());
            System.out.println("FIle size is :"+fobj.length());
            System.out.println("We can rea from file:"+fobj.canRead());
            System.out.println("We can write into file :"+fobj.canWrite());

        }
    }
    
    
    catch(Exception obj)
    {
        System.out.println("Exception occure");
    }
}
}