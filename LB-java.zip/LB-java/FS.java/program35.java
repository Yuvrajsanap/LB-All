import java.util.*;
import java.io.*;

class program35  //problems on string .IMP
{
    public static void main(String args[]) throws Exception
    {
        Scanner sobj=new Scanner(System.in);
        
        String str="Hello World";

        str=str.replaceAll("l","-");//replace all
        System.out.println(str);
    }
}
