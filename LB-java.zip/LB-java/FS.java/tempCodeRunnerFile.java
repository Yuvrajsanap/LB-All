System.out.println("Enter the data that you want to weite in the file ");
            // String Data = sobj.nextLine();