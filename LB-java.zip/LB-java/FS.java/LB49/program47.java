//Problems on Matrix.2D matrix.

import java.util.*;

public class program47
{
    public static void main(String args[])
    {
        Scanner sobj=new Scanner(System.in);
        int iRow=0,iCol=0;

        System.out.println("Enter number of rows:");
        iRow=sobj.nextInt();

        System.out.println("Enter number of colums: ");
        iCol=sobj.nextInt();

        int Arr[][]=new int [iRow][iCol];
    }
}