import java.util.*;

import java.io.*;//one file la durya file madhe copy karne

class program22 {
    
        public static void main(String arg[]) throws Exception
        {
            Scanner sobj=new Scanner(System.in);

            System.out.println("Enter the name of source file which is existing :");
            String sourceFile = sobj.nextLine();

            System.out.println("Enter the name of source file that we want to create :");
            String DestFile = sobj.nextLine();

            File fobj =new File(sourceFile);
            if(! fobj.exists())
            {
                System.out.println("Sourc file not existing..");
                return;
            }

            File fobj1=new File(DestFile);
            fobj1.createNewFile();


            FileInputStream fiobj = new FileInputStream(sourceFile);
            FileOutputStream foobj= new FileOutputStream(DestFile);

            byte Buffer[] = new byte[1024];
            int iRet=0;

            while((iRet = fiobj.read(Buffer)) != -1)
            {
                foobj.write(Buffer,0,iRet);
            }
        }
}
