import java.util.*;
import java.io.*;

class program38  //problems on string .IMP
{
    public static void main(String args[]) throws Exception
    {
        Scanner sobj=new Scanner(System.in);
        System.out.println("Enter string :");
        String str=sobj.nextLine();

        str=str.trim();

        System.out.println("After trim :"+str);

        str=str.replaceAll("\\s","");
        System.out.println("After replaceAll : "+str);

       
    }
}
