import java.util.*;
import java.io.*;

class program34  //problems on string .IMP
{
    public static void main(String args[]) throws Exception
    {
        Scanner sobj=new Scanner(System.in);
        
        String str= "     Hello  World  Demo     ";
        System.out.println("Length of str is :"+str.length());

        str =str.trim();     //To prerform trem method to remove void spacces
        System.out.println("Length of str is :"+str.length());

    }
}